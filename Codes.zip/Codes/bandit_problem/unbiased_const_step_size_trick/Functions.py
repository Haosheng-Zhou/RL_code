# Functions for epsilon_greedy.py
#-------------------------------------------------------------------------------
# The folowing function generates the rewards based on the value
# Input: the value_list and the action taken
# Output: the reward given
def generate_reward(value_list,action):
    import numpy as np
    # Only shift the mean, keep the variance as 1
    return np.random.randn() + value_list[action]

#-------------------------------------------------------------------------------
# The following function computes estimated values Q for each action based on
# an incremental update.
# Input: old Q_list,last reward, last action, alpha as step size parameter
# Output: a list containing estimated value for each action
def compute_Q_const_step(old_Q_list,reward,action,alpha):
    # Only update the Q value for the last action since only knowledge concerning
    # the last action has been gained
    Q_list = old_Q_list.copy()
    Q_list[action] = old_Q_list[action] + alpha * (reward - old_Q_list[action])
    return Q_list

#-------------------------------------------------------------------------------
# The following function computes o_n for the trick, o_n is like the reward with a constant step size
# alpha and 1 as reward.
# Input: max_time and alpha needed
# Output: a list as the value of o_n
def compute_o_list(max_time,alpha):
    o_list = list()
    for i in range(max_time):
        o_list.append(1 - (1 - alpha) ** i)
    return o_list

#-------------------------------------------------------------------------------
# The following function solves the non-stationary bandit problem with the unbiased
# const step size trick, this trick removes the initial bias when it also enjoys properties
# of const step size models that it solves non-stationary problems well.
# Input: how many times to repeat the experiment, how many time in a single experiment,
# how many possible actions are there, epsilon, what's the way to estimate values and the constant step parameter alpha (if applicable)
# Output: two arrays, one as the sum of rewards for all experiments, the other as the sum of indicators
# whether an action is the best action
def bandit_solve_unstationary(REPEAT_TIME,max_time,bandit_num,epsilon,compute_Q,alpha = 0):
    import numpy as np

    # Fix random seed
    np.random.seed(0)

    # Two arrays to return for plotting
    sum_reward_list = np.zeros(max_time)
    best_count_list = np.zeros(max_time)

    # Pre-calculate the sequence o_n for the trick use
    o_list = compute_o_list(max_time,alpha)

    for iter in range(REPEAT_TIME):
        # Generate value list randomly
        value_list = np.random.randn(bandit_num)

        # Record the best_action since the value will be changing
        best_action_list = list()
        reward_list = list()

        # action_count[i] keeps record of the number of appearance of action i
        action_count = [0] * bandit_num

        # Record the approximated value for each action
        Q_list = np.zeros(bandit_num)

        # Initial action and reward
        action = None
        reward = None

        for t in range(max_time):

            # Take the action with largest Q value with prob 1-epsilon
            r = np.random.random()
            if r < epsilon:
                # Select uniformly from all actions
                action = np.random.randint(bandit_num)
            else:
                action = np.argmax(np.array(Q_list))

            # COunt the appearance
            action_count[action] += 1

            # Generate the reward
            reward = generate_reward(value_list,action)
            reward_list.append(reward)

            # Whether the selected action is the best?
            # Note that the problem is not stationary, so the best action changes over time
            best_action = np.argmax(np.array(value_list))
            best_action_list.append(int(action == best_action))

            # Update the estimate of value for next use
            if compute_Q == 'const_step':
                # At each time, get the estimated value
                Q_list = compute_Q_const_step(Q_list,reward,action,alpha)
            elif compute_Q == 'sample_mean':
                # Use sample mean method to estimate
                # Have to first figure out alpha, it should be 1 over the times alpha has appeared
                actual_alpha = 1 / action_count[action]
                Q_list = compute_Q_const_step(Q_list,reward,action,actual_alpha)
            else:
                # The unbiased constant step size trick
                count = action_count[action]
                beta = alpha / o_list[count]
                Q_list = compute_Q_const_step(Q_list,reward,action,beta)

            # Update the values by a random walk following N(0,0.01)
            # So it's a non-stationary bandit problem now
            value_list += 0.1 * np.random.randn(bandit_num)

        sum_reward_list += np.array(reward_list)
        best_count_list += np.array(best_action_list)

    return sum_reward_list, best_count_list
