# This code is to exhibit that always taking greedy actions won't be good in long term.
import numpy as np
import matplotlib.pyplot as plt
from Functions import generate_reward, compute_Q_const_step, bandit_solve_unstationary

# Bandit number and max-time as parameters
REPEAT_TIME = 2000
bandit_num = 10
max_time = 5000
alpha = 0.1 # step-size parameter

# Subplots
fig, axs = plt.subplots(2)
#-------------------------------------------------------------------------------
# Apply the epsilon-greedy with epsilon = 0.1
# Use the sample mean to estimate Q
sum_reward_list, best_count_list = bandit_solve_unstationary(REPEAT_TIME,max_time,bandit_num,epsilon = 0.1,compute_Q = 'sample_mean',alpha = 0.1)

# Plot the average reward
avg_reward_list = sum_reward_list / REPEAT_TIME
best_percent_list = best_count_list / REPEAT_TIME * 100
axs[0].plot(range(max_time),avg_reward_list,label = r'$\varepsilon=0.1$,sample mean')
axs[1].plot(range(max_time),best_percent_list,label = r'$\varepsilon=0.1$,sample mean')

#-------------------------------------------------------------------------------
# Then the epsilon-greedy strategy wth epsilon = 0.1
# Use a fixed step size parameter to estimate Q
sum_reward_list, best_count_list = bandit_solve_unstationary(REPEAT_TIME,max_time,bandit_num,epsilon = 0.1,compute_Q = 'const_step',alpha = 0.1)

# Plot the average reward
avg_reward_list = sum_reward_list / REPEAT_TIME
best_percent_list = best_count_list / REPEAT_TIME * 100
axs[0].plot(range(max_time),avg_reward_list,label = r'$\varepsilon=0.1,\alpha=0.1$')
axs[1].plot(range(max_time),best_percent_list,label = r'$\varepsilon=0.1,\alpha=0.1$')

#-------------------------------------------------------------------------------
# Then the epsilon-greedy strategy wth epsilon = 0.1
# Use a fixed step size parameter to estimate Q
sum_reward_list, best_count_list = bandit_solve_unstationary(REPEAT_TIME,max_time,bandit_num,epsilon = 0.1,compute_Q = 'trick',alpha = 0.1)

# Plot the average reward
avg_reward_list = sum_reward_list / REPEAT_TIME
best_percent_list = best_count_list / REPEAT_TIME * 100
axs[0].plot(range(max_time),avg_reward_list,label = r'$\varepsilon=0.1,\alpha=0.1$, trick')
axs[1].plot(range(max_time),best_percent_list,label = r'$\varepsilon=0.1,\alpha=0.1$, trick')

#-------------------------------------------------------------------------------
axs[0].legend(loc = 'lower right')
axs[1].legend(loc = 'lower right')
plt.show()
