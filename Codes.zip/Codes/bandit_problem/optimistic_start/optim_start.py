# This code is to exhibit that always taking greedy actions won't be good in long term.
import numpy as np
import matplotlib.pyplot as plt
from Functions import generate_reward, compute_Q_const_step, bandit_solve_stationary

# Bandit number and max-time as parameters
REPEAT_TIME = 2000
bandit_num = 10
max_time = 1000

# Subplots
fig, axs = plt.subplots(2)

#-------------------------------------------------------------------------------
# First adopt the greedy strategy with optimistic start
# Two lists to record the reward and action
sum_reward_list, best_count_list = bandit_solve_stationary(REPEAT_TIME,max_time,bandit_num,0,5 * np.ones(bandit_num))

# Plot the average reward
avg_reward_list = sum_reward_list / REPEAT_TIME
best_percent_list = best_count_list / REPEAT_TIME * 100
axs[0].plot(range(max_time),avg_reward_list,label = r'$\varepsilon=0$, optimistic start')
axs[1].plot(range(max_time),best_percent_list,label = r'$\varepsilon=0$, optimistic start')

#-------------------------------------------------------------------------------
# Then the epsilon-greedy strategy wth epsilon = 0.1 but a normal start
# Two lists to record the reward and action
sum_reward_list, best_count_list = bandit_solve_stationary(REPEAT_TIME,max_time,bandit_num,0.01,np.zeros(bandit_num))

# Plot the average reward
avg_reward_list = sum_reward_list / REPEAT_TIME
best_percent_list = best_count_list / REPEAT_TIME * 100
axs[0].plot(range(max_time),avg_reward_list,label = r'$\varepsilon=0.01$, normal start')
axs[1].plot(range(max_time),best_percent_list,label = r'$\varepsilon=0.01$, normal start')

#-------------------------------------------------------------------------------
axs[0].legend(loc = 'lower right')
axs[1].legend(loc = 'lower right')
plt.show()
