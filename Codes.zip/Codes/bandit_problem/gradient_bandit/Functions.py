# Functions for epsilon_greedy.py
#-------------------------------------------------------------------------------
# The folowing function generates the rewards based on the value with normal perturbation
# Input: the value_list and the action taken
# Output: the reward given
def generate_reward(value_list,action):
    import numpy as np
    # Only shift the mean, keep the variance as 1
    return np.random.randn() + value_list[action]

#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
# The softmax function
# Input: 1-d np array
# Output: 1-d np array as a probability dist
def softmax(preference_array):
    import numpy as np
    exp_array = np.exp(preference_array)
    exp_sum = np.sum(exp_array)
    return exp_array / exp_sum

#-------------------------------------------------------------------------------
# The following function solves the bandit problem with gradient bandit alg based on
# updates of preferences
# Input: how many times to repeat the experiment, how many turns in a single experiment,
# how many possible actions are there, alpha as learning rate
# Output: two arrays, one as the sum of rewards for all experiments, the other as the sum of indicators
# whether an action is the best action
def bandit_solve_stationary(REPEAT_TIME,max_time,bandit_num,alpha,baseline_opt):
    import numpy as np

    # Fix the seed
    np.random.seed(0)

    # Two arrays to return for plotting
    sum_reward_list = np.zeros(max_time)
    best_count_list = np.zeros(max_time)

    for iter in range(REPEAT_TIME):
        # Each repeated experiment, generate value_list randomly, value_list distribute near 4
        value_list = 4 + np.random.randn(bandit_num)
        best_action = np.argmax(np.array(value_list))

        # Record whether the action taken is the best action
        # Record the reward at each time
        best_action_list = list()
        reward_list = list()

        # Record the preferences for each action, initialize as all zero
        H_list = np.zeros(bandit_num)

        # Initial action and reward
        action = None
        reward = None

        # Record the sum of all rewards
        reward_sum = 0

        for t in range(max_time):

            # Turn the preferences into prob dist as select the action with highest
            # prob
            EPS = 1e-8
            prob_list = softmax(H_list)
            max_prob = np.max(prob_list)
            max_prob_ind = np.argwhere(np.abs(prob_list - max_prob) < EPS)
            action = max_prob_ind[np.random.randint(len(max_prob_ind))][0]

            # Generate the reward and record
            reward = generate_reward(value_list,action)
            reward_list.append(reward)
            reward_sum += reward

            # Whether the selected action is the best?
            best_action_list.append(int(action == best_action))

            # Update the preferences for each action
            # Compute past mean
            # Whether to have the baseline or not
            if baseline_opt == 'past_mean':
                past_mean_reward = reward_sum / float(len(reward_list))
            elif baseline_opt == 'none':
                past_mean_reward = 0

            for action_ind in range(bandit_num):
                if action_ind == action:
                    # This action is picked up this turn
                    H_list[action_ind] = H_list[action_ind] + (alpha * (reward - past_mean_reward) * (1 - prob_list[action_ind]))
                else:
                    # This action is not picked up this turn
                    H_list[action_ind] = H_list[action_ind] + (alpha * (reward - past_mean_reward) * (- prob_list[action_ind]))

        sum_reward_list += np.array(reward_list)
        best_count_list += np.array(best_action_list)

    return sum_reward_list, best_count_list

#-------------------------------------------------------------------------------
# The following function solves the bandit problem with gradient bandit alg based on
# updates of preferences, but non stationary
# Input: how many times to repeat the experiment, how many turns in a single experiment,
# how many possible actions are there, alpha as learning rate
# Output: two arrays, one as the sum of rewards for all experiments, the other as the sum of indicators
# whether an action is the best action

def bandit_solve_unstationary(REPEAT_TIME,max_time,bandit_num,alpha,baseline_opt):
    import numpy as np

    # Fix random seed
    np.random.seed(0)

    # Two arrays to return for plotting
    sum_reward_list = np.zeros(max_time)
    best_count_list = np.zeros(max_time)

    for iter in range(REPEAT_TIME):
        # Each repeated experiment, generate value_list randomly, value_list distribute near 4
        value_list = 4 + np.random.randn(bandit_num)

        # Record whether the action taken is the best action
        # Record the reward at each time
        best_action_list = list()
        reward_list = list()

        # Record the preferences for each action, initialize as all zero
        H_list = np.zeros(bandit_num)

        # Initial action and reward
        action = None
        reward = None

        # Record the sum of all rewards
        reward_sum = 0

        for t in range(max_time):

            # Turn the preferences into prob dist as select the action with highest
            # prob
            EPS = 1e-8
            prob_list = softmax(H_list)
            max_prob = np.max(prob_list)
            max_prob_ind = np.argwhere(np.abs(prob_list - max_prob) < EPS)
            action = max_prob_ind[np.random.randint(len(max_prob_ind))][0]

            # Generate the reward
            reward = generate_reward(value_list,action)
            reward_list.append(reward)
            reward_sum += reward

            # Whether the selected action is the best?
            # Note that the problem is not stationary, so the best action changes over time
            best_action = np.argmax(np.array(value_list))
            best_action_list.append(int(action == best_action))

            # Update the preferences for each action
            # Compute past mean
            # Whether to have the baseline or
            if baseline_opt == 'past_mean':
                past_mean_reward = reward_sum / float(len(reward_list))
            elif baseline_opt == 'none':
                past_mean_reward = 0

            for action_ind in range(bandit_num):
                if action_ind == action:
                    # This action is picked up this turn
                    H_list[action_ind] += alpha * (reward - past_mean_reward) * (1 - prob_list[action_ind])
                else:
                    # This action is not picked up this turn
                    H_list[action_ind] += alpha * (reward - past_mean_reward) * (-prob_list[action_ind])

            # Update the values by a random walk following N(0,0.01)
            # So it's a non-stationary bandit problem now
            value_list += 0.1 * np.random.randn(bandit_num)

        sum_reward_list += np.array(reward_list)
        best_count_list += np.array(best_action_list)

    return sum_reward_list, best_count_list
