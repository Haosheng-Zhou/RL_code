# This code is to exhibit the performance of gradient bandit algorithms on nonstationary problem
import numpy as np
import matplotlib.pyplot as plt
from Functions import generate_reward, bandit_solve_unstationary

# Bandit number and max-time as parameters, bandit number is just the number of actions
# available and the max-time is the overall number of steps of this problem
REPEAT_TIME = 2000
bandit_num = 10
max_time = 1000

# Subplots
fig, axs = plt.subplots(2)

#-------------------------------------------------------------------------------
# First alpha = 0.1 with baseline
sum_reward_list, best_count_list = bandit_solve_unstationary(REPEAT_TIME,max_time,bandit_num,0.1,'past_mean')

# Plot the average reward
avg_reward_list = sum_reward_list / REPEAT_TIME
best_percent_list = best_count_list / REPEAT_TIME * 100
axs[0].plot(range(max_time),avg_reward_list,label = r'$\alpha=0.1$, past mean baseline')
axs[1].plot(range(max_time),best_percent_list,label = r'$\alpha=0.1$, past mean baseline')

#-------------------------------------------------------------------------------
# Then alpha = 0.1 with no baseline
sum_reward_list, best_count_list = bandit_solve_unstationary(REPEAT_TIME,max_time,bandit_num,0.1,'none')

# Plot the average reward
avg_reward_list = sum_reward_list / REPEAT_TIME
best_percent_list = best_count_list / REPEAT_TIME * 100
axs[0].plot(range(max_time),avg_reward_list,label = r'$\alpha=0.1$, no baseline')
axs[1].plot(range(max_time),best_percent_list,label = r'$\alpha=0.1$, no baseline')

#-------------------------------------------------------------------------------
# First alpha = 0.4 with baseline
sum_reward_list, best_count_list = bandit_solve_unstationary(REPEAT_TIME,max_time,bandit_num,0.4,'past_mean')

# Plot the average reward
avg_reward_list = sum_reward_list / REPEAT_TIME
best_percent_list = best_count_list / REPEAT_TIME * 100
axs[0].plot(range(max_time),avg_reward_list,label = r'$\alpha=0.4$, past mean baseline')
axs[1].plot(range(max_time),best_percent_list,label = r'$\alpha=0.4$, past mean baseline')

#-------------------------------------------------------------------------------
# Then alpha = 0.4 with no baseline
sum_reward_list, best_count_list = bandit_solve_unstationary(REPEAT_TIME,max_time,bandit_num,0.4,'none')

# Plot the average reward
avg_reward_list = sum_reward_list / REPEAT_TIME
best_percent_list = best_count_list / REPEAT_TIME * 100
axs[0].plot(range(max_time),avg_reward_list,label = r'$\alpha=0.4$, no baseline')
axs[1].plot(range(max_time),best_percent_list,label = r'$\alpha=0.4$, no baseline')

#-------------------------------------------------------------------------------
axs[0].legend(loc = 'lower right')
axs[1].legend(loc = 'lower right')
plt.show()
