# This code is to exhibit that always taking greedy actions won't be good in long term.
import numpy as np
import matplotlib.pyplot as plt
from Functions import generate_reward, compute_Q_const_step, bandit_solve_stationary
from Functions import bandit_solve_stationary_UCB

# Bandit number and max-time as parameters
REPEAT_TIME = 2000
bandit_num = 10
max_time = 1000

# Subplots
fig, axs = plt.subplots(2)

#-------------------------------------------------------------------------------
# First adopt the epsilon-greedy strategy with epsilon = 0.1
# Two lists to record the reward and action
sum_reward_list, best_count_list = bandit_solve_stationary(REPEAT_TIME,max_time,bandit_num,0.1)

# Plot the average reward
avg_reward_list = sum_reward_list / REPEAT_TIME
best_percent_list = best_count_list / REPEAT_TIME * 100
axs[0].plot(range(max_time),avg_reward_list,label = r'$\varepsilon=0.1$')
axs[1].plot(range(max_time),best_percent_list,label = r'$\varepsilon=0.1$')

#-------------------------------------------------------------------------------
# Then the UCB
# Two lists to record the reward and action, with c = 2
sum_reward_list, best_count_list = bandit_solve_stationary_UCB(REPEAT_TIME,max_time,bandit_num,2)

# Plot the average reward
avg_reward_list = sum_reward_list / REPEAT_TIME
best_percent_list = best_count_list / REPEAT_TIME * 100
axs[0].plot(range(max_time),avg_reward_list,label = r'$c=2$, UCB')
axs[1].plot(range(max_time),best_percent_list,label = r'$c=2$, UCB')

#-------------------------------------------------------------------------------
axs[0].legend(loc = 'lower right')
axs[1].legend(loc = 'lower right')
plt.show()
