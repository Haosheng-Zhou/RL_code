# The file contains functions for the Gridworld model.

#-------------------------------------------------------------------------------
# The function judges whether a coordinate is a legal state
# Input: a tuple as state
# Output: whether it's legal inside 5\times 5 square
def is_legal_state(state):
    if state[0] < -0.5 or state[0] > 4.5 or state[1] < -0.5 or state[1] > 4.5:
        return False
    return True

#-------------------------------------------------------------------------------
# The function returns the action with the equiprobable policy
# Input: the state we are at (actually not used)
# Output: the action to take according to the policy, taken from {N,S,E,W}
def action_to_take(state):
    import numpy as np
    r = np.random.rand()
    if r < 1/4:
        return 'N'
    elif r < 1/2:
        return 'S'
    elif r < 3/4:
        return 'E'
    else:
        return 'W'

#-------------------------------------------------------------------------------
# The function computes the reward and next state based on state and action
# Input: state and action, state as a tuple, action as a string
# Output: a real number as reward and a tuple as next state
def get_reward_state(state,action):
    # Two special cases
    if state == (1,4):
        next_state = (1,0)
        reward = 10
        return reward,next_state
    elif state == (3,4):
        next_state = (3,2)
        reward = 5
        return reward,next_state

    # General cases
    if action == 'N':
        next_state = (state[0],state[1] + 1)
    elif action == 'S':
        next_state = (state[0],state[1] - 1)
    elif action == 'W':
        next_state = (state[0] - 1,state[1])
    elif action == 'E':
        next_state = (state[0] + 1,state[1])

    # Whether it's still in the square
    if is_legal_state(next_state):
        reward = 0
        return reward,next_state
    else:
        # Does not move and receive reward -1
        next_state = state
        reward = -1
        return reward,next_state

#-------------------------------------------------------------------------------
# The function simulates the gridworld with given time limit to stop
# Input: the maximum time to simulate, the initial state
# Output: four lists, one for state, one for action, one for reward
def run_gridworld(MAX_TIME,init_state):
    # Record the history
    state_list = list()
    action_list = list()
    reward_list = list()

    # Initial state
    state = init_state

    for t in range(MAX_TIME):
        # Figure out the action, reward and next_state
        action = action_to_take(state)
        reward,next_state = get_reward_state(state,action)

        # Record the state,action,reward
        state_list.append(state)
        action_list.append(action)
        reward_list.append(reward)

        # Update the state
        state = next_state

    return state_list,action_list,reward_list

#-------------------------------------------------------------------------------
# The function computes the return list with given time to stop
# Input: max_time, reward_list, gamma as discount rate
# Output: return_list, length as MAX_TIME - 1
def compute_return_list(MAX_TIME,reward_list,gamma):
    return_list = [0] * (MAX_TIME - 1)

    # Use the recurrence G_t = R_{t+1} + gamma * G_{t+1}, note that the reward for time
    # t is actually R_{t+1}
    return_list[-1] = reward_list[-1]
    for t in range(MAX_TIME - 3,-1,-1):
        return_list[t] = reward_list[t] + gamma * return_list[t + 1]

    return return_list

#-------------------------------------------------------------------------------
# The function does Monte Carlo simulations to estimate the state value function
# of the model
# Input: number of chains to generate, max_time for each chain, gamma as discount rate
# Output: a 5*5 matrix as the state value function
def MC_estimate(NUM_CHAIN,MAX_TIME,gamma):
    import numpy as np
    from collections import defaultdict
    # State value function
    v_function = np.zeros((5,5))

    # Bins for each of the state to store the return values
    state_bins = defaultdict(list)

    # Begin simulation
    for ind in range(NUM_CHAIN):
        # Make sure that each state can be selected as initial state
        init_x = np.random.randint(0,5)
        init_y = np.random.randint(0,5)
        init_state = (init_x,init_y)
        state_list, action_list, reward_list = run_gridworld(MAX_TIME,init_state)

        # Get return list
        return_list = compute_return_list(MAX_TIME,reward_list,gamma)

        # Record the returns in bins
        for i in range(len(return_list) - 1,0,-1):
            state_bins[state_list[i]].append(return_list[i])

    # After simulation, compute means as estimates
    for i in range(5):
        for j in range(5):
            v_function[i,j] = np.mean(state_bins[(i,j)])

    return v_function

#-------------------------------------------------------------------------------
# Measure whether two floats are the same value
# Input: two floats
# Output: true or false
def is_equal(a,b):
    import numpy as np
    EPS = 1e-4
    if np.abs(a - b) < EPS:
        return True
    else:
        return False

#-------------------------------------------------------------------------------
# The function does fixed point iteration to estimate the optimal state value functions
# Input: gamma, error tolerance as stopping criterion
# Output: a 5*5 matrix as the optimal state value function
def estimate_v_star(gamma,TOL):
    import numpy as np

    # Do the iteration until the estimates are close enough measured by Frobenius norm
    last_est = np.ones((5,5))
    est = np.zeros((5,5))

    while np.linalg.norm(last_est - est,'fro') > TOL:
        # Fixed point iteration
        last_est = est.copy()

        for i in range(5):
            for j in range(5):
                state = (i,j)
                # Update the value for state (i,j)
                # Deal with two special states (1,4), (3,4)
                if state == (1,4):
                    # Next state must be (1,0) with reward 10, four actions are the same
                    est[i,j] = 10 + gamma * last_est[1,0]
                elif state == (3,4):
                    # Next state must be (3,2) with reward 5, four actions are the same
                    est[i,j] = 5 + gamma * last_est[3,2]
                else:
                    # Normal cases, consider boundary cases
                    # 'N' action
                    next_state = (state[0],state[1] + 1)
                    if is_legal_state(next_state):
                        north_value = gamma * last_est[next_state[0],next_state[1]]
                    else:
                        north_value = -1 + gamma * last_est[i,j]
                    # 'S' action
                    next_state = (state[0],state[1] - 1)
                    if is_legal_state(next_state):
                        south_value = gamma * last_est[next_state[0],next_state[1]]
                    else:
                        south_value = -1 + gamma * last_est[i,j]
                    # 'W' action
                    next_state = (state[0] - 1,state[1])
                    if is_legal_state(next_state):
                        west_value = gamma * last_est[next_state[0],next_state[1]]
                    else:
                        west_value = -1 + gamma * last_est[i,j]
                    # 'E' action
                    next_state = (state[0] + 1,state[1])
                    if is_legal_state(next_state):
                        east_value = gamma * last_est[next_state[0],next_state[1]]
                    else:
                        east_value = -1 + gamma * last_est[i,j]

                    # Take the maximum among 4 values
                    est[i,j] = np.max([north_value,south_value,west_value,east_value])

    return est
