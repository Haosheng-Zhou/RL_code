# This code is to estimate the optimal state value function and show the best actions
# when at each state

import numpy as np
import pandas as pd
from collections import defaultdict
from Functions import estimate_v_star, is_equal, is_legal_state

# Fixed point iteration for the Bellman optimality equation
gamma = 0.9
est = estimate_v_star(gamma,1e-4)

print(pd.DataFrame(est))


# Figure out best actions for each state
best_actions = dict()

last_est = est.copy()
for i in range(5):
    for j in range(5):
        state = (i,j)
        # Update the value for state (i,j)
        # Deal with two special states (1,4), (3,4)
        if state == (1,4):
            best_actions[state] = 'NSWE'
        elif state == (3,4):
            best_actions[state] = 'NSWE'
        else:
            # Normal cases, consider boundary cases
            # 'N' action
            next_state = (state[0],state[1] + 1)
            if is_legal_state(next_state):
                north_value = gamma * last_est[next_state[0],next_state[1]]
            else:
                north_value = -1 + gamma * last_est[i,j]
            # 'S' action
            next_state = (state[0],state[1] - 1)
            if is_legal_state(next_state):
                south_value = gamma * last_est[next_state[0],next_state[1]]
            else:
                south_value = -1 + gamma * last_est[i,j]
            # 'W' action
            next_state = (state[0] - 1,state[1])
            if is_legal_state(next_state):
                west_value = gamma * last_est[next_state[0],next_state[1]]
            else:
                west_value = -1 + gamma * last_est[i,j]
            # 'E' action
            next_state = (state[0] + 1,state[1])
            if is_legal_state(next_state):
                east_value = gamma * last_est[next_state[0],next_state[1]]
            else:
                east_value = -1 + gamma * last_est[i,j]

            # Which one attains
            if is_equal(est[i,j],north_value):
                best_actions[state] = best_actions.get(state,'') + 'N'
            if is_equal(est[i,j],south_value):
                best_actions[state] = best_actions.get(state,'') + 'S'
            if is_equal(est[i,j],west_value):
                best_actions[state] = best_actions.get(state,'') + 'W'
            if is_equal(est[i,j],east_value):
                best_actions[state] = best_actions.get(state,'') + 'E'
print(pd.DataFrame(best_actions.items()))
