# This functions shows the state value function of the Grid World model


import numpy as np
import pandas as pd
from Functions import MC_estimate, compute_return_list, run_gridworld

# FIx seed
np.random.seed(1)

# Set parameter
NUM_CHAIN = 1000
MAX_TIME = 20000
gamma = 0.9


#state_list,action_list,reward_list = run_gridworld(MAX_TIME,(2,2))
#return_list = compute_return_list(MAX_TIME,reward_list,gamma)

# Estimate
v_function = MC_estimate(NUM_CHAIN,MAX_TIME,gamma)
print(pd.DataFrame(data = v_function))
