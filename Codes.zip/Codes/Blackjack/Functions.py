# This code contains functions for the Balckjack estimation problems

#-------------------------------------------------------------------------------
# This function simulates card drawing process in blackjack
# Input: nothing
# Output: an integer as the card drawn
def draw_card():
    import numpy as np
    card = np.random.randint(1,14)
    # Ace is denoted as 1
    # Face cards work as 10
    if card in [11,12,13]:
        card = 10
    return card

#-------------------------------------------------------------------------------
# This function calculates the initial sum of player and dealer
# Input: first two cards
# Output: an int value as the sum
def figure_init_sum(card_1,card_2):
    # Blackjacks (10 + A)
    if (card_1 == 1 and card_2 == 10) or (card_1 == 10 and card_2 == 1):
        return 21

    # Two aces (11 + 1)
    if card_1 == 1 and card_2 == 1:
        return 12

    # Normal cases, aces are always explained as 11
    if card_1 == 1:
        card_1 = 11
    if card_2 == 1:
        card_2 = 11
    return card_1 + card_2

#-------------------------------------------------------------------------------
# This function judges whether immediate win/lose happen
# Input: player and dealer's cards' initial sums
# Output: a flag indicating whether the game has ended,
# two reward values for player and dealer (-1 for lose, 0 for draw, 1 for win)
def immediate_win(p_sum,d_sum):
    p_blackjack = d_blackjack = False
    # Whether there's balckjack for both sides
    if p_sum == 21:
        p_blackjack = True
    if d_sum == 21:
        d_blackjack = True

    game_ended = False
    if p_blackjack and d_blackjack:
        # Draw
        game_ended = True
        return game_ended,0,0
    if p_blackjack and not d_blackjack:
        game_ended = True
        return game_ended,1,-1
    if d_blackjack and not p_blackjack:
        game_ended = True
        return game_ended,-1,1
    if not p_blackjack and not d_blackjack:
        return game_ended,0,0

#-------------------------------------------------------------------------------
# This function generates action based on policy and state
# Input: the state as 2-tuple
# Output: the action according to the policy
def action_policy(state):
    # Here the policy is that only sticks if p_sum is 20 or 21
    # Action 0 means stick and action 1 means hit
    p_sum = state[0]
    if p_sum in [20,21]:
        return 0
    return 1

#-------------------------------------------------------------------------------
# This function generates dealer's action
# Input: the d_sum
# Output: the action
def action_dealer(d_sum):
    # Here the policy is that only sticks if d_sum is >= 17
    # Action 0 means stick and action 1 means hit
    if d_sum >= 17:
        return 0
    return 1

#-------------------------------------------------------------------------------
# This function simulates the Blackjack for a single time
# Input: nothing
# Output: three lists of states, actions, rewards
def simulate_blackjack():
    # Three lists
    state_list = list()
    action_list = list()
    reward_list = list()

    # First draw two cards for player and dealer
    p_card_1 = draw_card()
    p_card_2 = draw_card()
    d_card_1 = draw_card()
    d_card_2 = draw_card()

    # Dealer should let the player know what first card is as part of the state
    state_d = d_card_1

    # Figure out initial sums
    p_sum = figure_init_sum(p_card_1,p_card_2)
    d_sum = figure_init_sum(d_card_1,d_card_2)
    game_ended, p_reward, d_reward = immediate_win(p_sum,d_sum)

    # If p_sum is less than 12, keep drawing cards until it gets over 12
    while p_sum < 12:
        p_sum += draw_card()

    # Set state
    state = (p_sum,state_d)

    # If the game has ended, record everything and return
    if game_ended:
        reward = p_reward
        # Pick an action randomly
        action = np.randint(0,2)
        state_list.append(state)
        action_list.append(action)
        reward_list.append(reward)
        return state_list,action_list,reward_list

    # Otherwise the player begins to take actions
    while p_sum <= 21:
        # Make actions based on state and policy
        action = action_policy(state)
        # All rewards are 0 in the process
        reward = 0

        # Record state, action, reward
        state_list.append(state)
        action_list.append(action)
        reward_list.append(reward)

        if action == 1:
            # Hit
            new_card = draw_card()
            # Ace must work as 1 now
            p_sum += new_card
        else:
            # Stick
            break

        # Update state
        state = (p_sum,state_d)

    # Check whether busted
    if p_sum > 21:
        # The last reward should be -1
        reward_list[-1] = -1
        return state_list,action_list,reward_list

    # If not busted, the dealer shall begin to take actions
    while d_sum <= 21:
        # Make actions
        d_action = action_dealer(d_sum)

        if d_action == 1:
            # Hit
            new_card = draw_card()
            # Ace must work as 1 now
            d_sum += new_card
        else:
            # Stick
            break

    # Check whether busted
    if d_sum > 21:
        # The last reward should be 1, player wins
        reward_list[-1] = 1
        return state_list,action_list,reward_list

    # If both not busted, compare
    if p_sum > d_sum:
        # Player wins
        reward_list[-1] = 1
    elif p_sum < d_sum:
        # Dealer wins
        reward_list[-1] = -1
    else:
        # Draw
        reward_list[-1] = 0

    return state_list,action_list,reward_list

#-------------------------------------------------------------------------------
# This function use first-visit MC to estimate the state value function
# Input: number of samples generated
# Output: a list as state value function estimate
def MC_estimate_v_pi(SAMPLE_NUM):
    import numpy as np
    from collections import defaultdict
    # A dict to keep track with the return of different state values
    state_ret_dict = defaultdict(list)

    for iter in range(SAMPLE_NUM):
        # simulate
        state_list, action_list, reward_list = simulate_blackjack()

        # Since it's nondiscounted, no need to keep return_list
        # Record everything into dictionary
        for state in state_list:
            # The last reward is always the return
            state_ret_dict[state].append(reward_list[-1])

    # Take an average for each list in the dict, store it in a matrix
    v_func = np.zeros((30,30))
    for state in state_ret_dict:
        ret_list = state_ret_dict[state]
        v_func[state[0],state[1]] = np.mean(ret_list)

    # The first index is from 12 to 21 and the second index is from 1 to 10
    v_func = v_func[12:22,1:11]

    return v_func
