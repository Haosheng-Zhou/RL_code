# This code is to estimate the state value function for a certain policy in Blackjack

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator
from Functions import figure_init_sum, simulate_blackjack, MC_estimate_v_pi

# Random seed
np.random.seed(0)

# Estimated state value function
SAMPLE_NUM = 500000
v_func = MC_estimate_v_pi(SAMPLE_NUM)
print(pd.DataFrame(v_func))

# Plot as 3D surface
p_sum = np.linspace(12,21,10)
d_card_1 = np.linspace(1,10,10)
d_card_1,p_sum = np.meshgrid(d_card_1,p_sum)

fig, ax = plt.subplots(subplot_kw = {"projection": "3d"})
surf = ax.plot_surface(d_card_1,p_sum,v_func,cmap = cm.coolwarm, linewidth = 0, antialiased=False);

# Customize the z axis.
ax.set_zlim(-1, 1)
ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter('{x:.02f}')
# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)
plt.show()














#END
