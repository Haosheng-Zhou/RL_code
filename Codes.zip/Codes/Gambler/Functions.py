# This code is to store functions for the gambler's problem
#-------------------------------------------------------------------------------
# This function judges whether two floats are the same
def is_equal(a,b):
    import numpy as np
    if np.abs(a - b) < 1e-4:
        return True
    else:
        return False

#-------------------------------------------------------------------------------
# This function provides dynamics for MDP
# Input: s',r,s,a,p_h as parameter
# Output: p(s',r|s,a), return None if not exist
def p(s_,r,s,a,p_h):
    # Terminal states
    # 0 transit to 0 with reward 0
    if s == 0 and s_ == 0 and a == 0 and r == 0:
        return 1
    # 100 transit to 0 with reward 1
    if s == 100 and s_ == 0 and a == 0 and r == 1:
        return 1

    # Other states, reward is always 0
    if a == 0 and s == s_ and r == 0:
        return 1
    if s_ == s + a and r == 0:
        return p_h
    if s_ == s - a and r == 0:
        return 1 - p_h
    # Remaining are dynamics that not exist
    return None

#-------------------------------------------------------------------------------
# This function implements the value iterations method
# Input: error tolerance and the parameter p_h
# Output: an array as the optimal value function
def value_iter(TOL,p_h):
    import numpy as np

    # Altogether 101 states, 0 and 100 are special states with values always equal to 0,1
    v_init = np.zeros(101)
    v_init[0] = 0
    v_init[100] = 1 # Cancel this sentence to get v_star graph

    # Iteration starts, fixed point iteration
    v = v_init
    last_v = v_init - np.ones(101)
    while np.linalg.norm(v - last_v) > TOL:
    #for k in range(5):
        last_v = v.copy()

        # Update the estimate for each state
        for s in range(101):
            sum_list = list()

            # For each action, get the sum
            for a in range(np.min([s,100 - s]) + 1):
                # What's possible values for s' and r
                if s == 0:
                    s_list = [0]
                elif s == 100:
                    s_list = [0]
                else:
                    # s' can only be s-a or s+a, r can only be 0,1 in normal case
                    if a == 0:
                        # No gamble
                        s_list = [s]
                    else:
                        # Positive stake
                        s_list = [s - a,s + a]


                r_list = [0,1]
                sum = 0
                for s_ in s_list:
                    for r in r_list:
                        # Get dynamic value
                        p_val = p(s_,r,s,a,p_h)

                        # If dynamic exists, add it to sum
                        if p_val != None:
                            sum += p_val * (r + last_v[s_])
                # Record this sum
                sum_list.append(sum)
            # Take maximum in the sum_list
            v[s] = np.max(sum_list)
    return v
#-------------------------------------------------------------------------------
# This fuction finds out the optimal action of each state after knowing v_star
# Input: optimal value function v_star,p_h
# Output: a dictionary of list, contained all best actions for a given state
def get_best_action(v_star,p_h):
    import numpy as np
    from collections import defaultdict

    # Record best actions
    best_actions_list_dict = defaultdict(list)

    # Update the estimate for each state
    for s in range(101):

        # For each action, record the sums
        action_sum_list = np.zeros(101)
        for a in range(np.min([s,100 - s]) + 1):
            # What's possible values for s' and r
            if s == 0:
                s_list = [0]
            elif s == 100:
                s_list = [0]
            else:
                # s' can only be s-a or s+a, r can only be 0,1 in normal case
                if a == 0:
                    # No gamble
                    s_list = [s]
                else:
                    # Positive stake
                    s_list = [s - a,s + a]
            r_list = [0,1]
            sum = 0
            for s_ in s_list:
                for r in r_list:
                    # Get dynamic value
                    p_val = p(s_,r,s,a,p_h)

                    # If dynamic exists, add it to sum
                    if p_val != None:
                        sum += p_val * (r + v_star[s_])
            # Record this sum
            action_sum_list[a] = sum

        # Which action achieves the maximum?
        all_best_action = list()
        for a in range(np.min([s,100 - s]) + 1):
            if is_equal(action_sum_list[a],v_star[s]):
                # Whether attains max in Bellman optimality equation
                best_actions_list_dict[s].append(a)
    return best_actions_list_dict

#-------------------------------------------------------------------------------
