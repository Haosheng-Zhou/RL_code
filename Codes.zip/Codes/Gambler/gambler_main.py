# This code is to implement the gambler's problem and show the DP methods to
# find optimal policy / value functions

import numpy as np
import matplotlib.pyplot as plt
from Functions import value_iter, get_best_action

# Random seed
np.random.seed(0)

# The parameters
# The probability of getting a head
p_h = 0.5

v_star = value_iter(1e-4,p_h)
best_action_list_dict = get_best_action(v_star,p_h)
fig, axes = plt.subplots(2)
axes[0].plot(range(101),v_star)

# Plot all best actions as scatter plot
for state, best_action_list in best_action_list_dict.items():
    for best_action in best_action_list:
        axes[1].scatter(state,best_action,s = 2)

plt.show()








#END
